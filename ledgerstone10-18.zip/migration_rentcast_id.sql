-- Ledgerstone: link saved properties to their RentCast record.
-- Additive and safe to re-run. Does not touch existing rows, policies, or other tables.
-- Existing Row Level Security policies on public.properties automatically cover the new column.

alter table public.properties
  add column if not exists rentcast_id text;

-- Prevents the same RentCast property being added twice by the same user.
-- Properties without a RentCast id (entered manually) are unaffected.
create unique index if not exists properties_user_rentcast_id_key
  on public.properties (user_id, rentcast_id)
  where rentcast_id is not null;
